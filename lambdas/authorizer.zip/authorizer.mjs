export async function handler(event) {
    // Retrieve the token from the headers (supports both "Authorization" and "authorization")
    const token = event.headers?.Authorization || event.headers?.authorization;
    
    // For this demo, simply check if the token equals "allow"
    if (token === "allow") {
      return { isAuthorized: true };
    } else {
      return { isAuthorized: false };
    }
  }
  